package lista05q02;

import javax.swing.JOptionPane;

public class Quadrado {
	private float lado;
	private static int numLados = 4;
	
	public void setLado (float l)
	{
		lado = l;
	}
	
	public float getLado()
	{
		return lado;
	}
	
	public static void setNumLados(int nl)
	{
		numLados=nl;
	}
	
	public static int getNumLados()
	{
		return numLados;
	}
	public Quadrado()
	{
		lado = Float.parseFloat(JOptionPane.showInputDialog("Digite a medida do lado do quadrado"));
	}
	
	public double CalcularDiagonal()
	{
		return Math.sqrt(Math.pow(lado,2)+Math.pow(lado, 2));
	}
	
	public float CalcularPerimetro()
	{
		return (4*lado);
	}
	
	public float CalcularArea()
	{
		return (lado*lado);
	}
}
