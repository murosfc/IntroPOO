package lista05q02;

import javax.swing.JOptionPane;

public class TesteQuadrado {

	public static void main(String[] args) {
		Quadrado ObjetoQuadrado = new Quadrado();	
		
		JOptionPane.showMessageDialog(null, "Lado informado para o quadrado = " + String.format("%.2f",ObjetoQuadrado.getLado())+
				"\nNumero de lados = " +Quadrado.getNumLados()+
				"\nDiagonal do quadrado = "+ String.format("%.2f", ObjetoQuadrado.CalcularDiagonal())+
				"\nPer�metro do quadrado = " + String.format("%.2f",ObjetoQuadrado.CalcularPerimetro())+
				"\n�rea do quadrado = " + String.format("%.2f",ObjetoQuadrado.CalcularArea()));
	}

}
