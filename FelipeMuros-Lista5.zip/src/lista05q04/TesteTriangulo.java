package lista05q04;

import javax.swing.JOptionPane;

public class TesteTriangulo {

	public static void main(String[] args) {
		Triangulo ObjTriangulo = new Triangulo();
				
		if (!ObjTriangulo.ValidaTriangulo())
		{
			JOptionPane.showMessageDialog(null, "Medidas informadas n�o formam um tri�ngulo","ERRO",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		
		JOptionPane.showMessageDialog(null, "Triangulo AxBxC = "+ String.format("%.2f",ObjTriangulo.getLadoA())
		+"x"+String.format("%.2f",ObjTriangulo.getLadoB())+"x"+String.format("%.2f",ObjTriangulo.getLadoC()));
		if (ObjTriangulo.RetornarHipotenusa() != 0)
			JOptionPane.showMessageDialog(null,"Hipotenusa do trin�ngulo = "+ String.format("%.2f",ObjTriangulo.RetornarHipotenusa()));
		JOptionPane.showMessageDialog(null,"O tri�ngulo � do tipo "+ ObjTriangulo.VerificarTipo()
			+ "\nA �rea do tri�ngulo � = " + String.format("%.2f",ObjTriangulo.CalcularArea())
				+"\nO per�mentro do tri�ngulo � = " + String.format("%.2f",ObjTriangulo.CalcularPerimetro()));
	}
}
