package lista05q07;

import javax.swing.JOptionPane;

public class TestHora {

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Ser�o solicitadas duas entradas de horas,"
				+ "\n a primeira � a base a segunda � a quantidade de horas para somar e subtrair");
		Hora ObjetoHora1 = new Hora();
		Hora ObjetoHora2 = new Hora();	
		
		JOptionPane.showMessageDialog(null, "Hora informada: " + ObjetoHora1.getHora()
		+ "\nHora = " + ObjetoHora1.RetornarHora()
		+ "\nMinuto = " + ObjetoHora1.RetornarMinuto()
		+ "\nSegundo = " + ObjetoHora1.RetornarSegundo()
		+ "\nHora para calculo informada: " + ObjetoHora2.getHora()
		+ "\nSoma das Horas = " + ObjetoHora1.SomarHora(ObjetoHora2)
		+ "\nSubtra��o das Horas = " + ObjetoHora1.SubtrairHora(ObjetoHora2));
	}

}
