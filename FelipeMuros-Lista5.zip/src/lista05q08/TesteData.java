package lista05q08;

import javax.swing.JOptionPane;

public class TesteData {

	public static void main(String[] args) {
		Data ObjData= new Data();		
		
		int DiasSomarSubtrair = Integer.parseInt(JOptionPane.showInputDialog("Digite quantos dias deseja somar e subtrair � data informada"));
		
		JOptionPane.showMessageDialog(null,"Dia = " + ObjData.RetornaDia()+ "\nM�s = " + ObjData.RetornaMes()+"\nAno = " + ObjData.RetornaAno()
		+"\nData inserida " +ObjData.getData() +" + " + DiasSomarSubtrair + " dias = " + ObjData.SomarDias(DiasSomarSubtrair)
		+"\nData inserida " +ObjData.getData() +" - " + DiasSomarSubtrair + " dias = " + ObjData.SubtrairDias(DiasSomarSubtrair));
	}
}

