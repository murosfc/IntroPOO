package lista05q08;

import javax.swing.JOptionPane;

public class Data {
	private String data;
	
	public void setData (String datainserir)
	{
		data=datainserir;
	}
	
	public String getData()
	{
		return data;
	}
	
	public Data()
	{
		data = JOptionPane.showInputDialog("Digite a data no formato dd/mm/aaaa");
		boolean valida = ValidaData(data);
		if (valida)
		{			
			JOptionPane.showMessageDialog (null,"Data v�lida e inserida com sucesso");
		}
		else 
		{
			JOptionPane.showMessageDialog (null,"Data inv�lida, tente novamente","ERR0",JOptionPane.ERROR_MESSAGE);			
			System.exit(0);
		}
	}
	
	public boolean ValidaData(String date)
	{
		int dia= Integer.parseInt(""+date.charAt(0)+date.charAt(1));
		int mes= Integer.parseInt(""+date.charAt(3)+date.charAt(4));
		int ano= Integer.parseInt(""+date.charAt(6)+date.charAt(7)+date.charAt(8)+date.charAt(9));
		if (this.QuantidadeDiasMes(mes, ano)>=dia)
			return true;		
		else return false;
	}
	
	public int RetornaDia() {
		String dia = ""+data.charAt(0)+data.charAt(1);
		return Integer.parseInt(dia);
	}
	
	public int RetornaMes() {
		String mes = ""+data.charAt(3)+data.charAt(4);
		return Integer.parseInt(mes);
	}
	
	public int RetornaAno() {
		String ano = ""+data.charAt(6)+data.charAt(7)+data.charAt(8)+data.charAt(9);
		return Integer.parseInt(ano);
	}
	
	public String SomarDias(int dias)
	{
		int dia=this.RetornaDia(),mes=this.RetornaMes(),ano=this.RetornaAno();
		while (dias != 0)
		{
			if (dia+dias > this.QuantidadeDiasMes(mes, ano))
			{
				dias=dias-(this.QuantidadeDiasMes(mes, ano)-dia+1); //+1 no final � o dia um do m�s seguinte
				dia=1;				
				if (mes+1 > 12)
				{
					mes=1;
					ano+=1;
				}
				else mes+=1;
			}
			else 
			{
				dia=dia+dias;
				dias=0;
			}			
		}
		return ""+String.format("%02d",dia)+"/"+String.format("%02d",mes)+"/"+String.format("%02d",ano);
	}
	
	public int QuantidadeDiasMes(int mes , int ano)
	{
		int Mes31Dias[]= {1,3,5,7,8,10,12};
		for (int i=0;i<7;i++)
		{
			if (mes == Mes31Dias[i])
				return 31;
		}
		if (mes==2)
		{
			if (ano%4 ==0)
				return 29;
			else return 28;
		}
		else return 30;		
	}
	
	public String SubtrairDias(int dias)
	{
		int dia=this.RetornaDia(),mes=this.RetornaMes(),ano=this.RetornaAno();
		while (dias != 0)
		{
			if (dia-dias < 0)
			{
				dias=dias-dia; 							
				if (mes-1 < 1)
				{
					mes=12;
					ano-=1;
				}
				else mes-=1;
				dia=this.QuantidadeDiasMes(mes, ano);
			}
			else 
			{
				dia=dia-dias;
				dias=0;
			}			
		}
		return ""+String.format("%02d",dia)+"/"+String.format("%02d",mes)+"/"+String.format("%02d",ano);
	}
}
