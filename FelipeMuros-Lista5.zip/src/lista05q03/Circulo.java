package lista05q03;

import javax.swing.JOptionPane;

public class Circulo {
	private float raio;	
	
	public void setRaio(float r)
	{
		raio=r;
	}
	
	public float getRaio()
	{
		return raio;
	}
	
	public Circulo()
	{
		raio = Float.parseFloat(JOptionPane.showInputDialog("Digite o raio do c�rculo"));
	}
	
	public double CalcularArea()
	{
		return Math.PI*Math.pow(raio, 2);
	}
	
	public double CalcularPerimetro()
	{
		return 2*Math.PI*raio;
	}
	
	public float CalcularDiametro()
	{
		return 2*raio;
	}
}
