package lista05q03;

import javax.swing.JOptionPane;

public class TesteCirculo {

	public static void main(String[] args) {
		Circulo ObjetoCirculo = new Circulo();		
	
		JOptionPane.showMessageDialog(null,"Raio do c�rculo = " + String.format("%.2f",ObjetoCirculo.getRaio())+
				"\nDi�metro do circulo = " + String.format("%.2f",ObjetoCirculo.CalcularDiametro())+
				"\n�rea do circulo = " + String.format("%.2f", ObjetoCirculo.CalcularArea()) +
				"\nPer�metro do ciculo =" + String.format("%.2f", ObjetoCirculo.CalcularPerimetro()));
	}

}
