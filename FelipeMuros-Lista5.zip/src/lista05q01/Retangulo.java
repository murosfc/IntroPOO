package lista05q01;

import javax.swing.JOptionPane;

public class Retangulo {
	private float base, altura;
	static int numLados=4;
	
	public void setAltura (float a)
	{
		altura=a;
	}
	
	public void setBase (float b)
	{
		base=b;
	}
	
	public float getAltura ()
	{
		return altura;
	}
	
	public float getBase()
	{
		return base;
	}
	
	public static void setNumLados(int nl)
	{
		numLados=nl;
	}
	
	public static int getNumLados()
	{
		return numLados;
	}
	
	public Retangulo()
	{
		base= Float.parseFloat(JOptionPane.showInputDialog("Digite a base do ret�ngulo"));
		altura= Float.parseFloat(JOptionPane.showInputDialog("Digite a altura do ret�ngulo"));		
	}
	
	public float calculcarArea()
	{
		return base*altura;
	}
	
	public float calcularPerimetro()
	{
		return 2*(base+altura);
	}
	
	public double calcularDiagonal()
		{
			return Math.sqrt(Math.pow(altura, 2)+Math.pow(base, 2));
		}

}
