package lista05q01;

import javax.swing.JOptionPane;

public class TesteRetangulo
{
	public static void main(String[] args)
	{
		Retangulo objetoRetangulo = new Retangulo();		
		
		JOptionPane.showMessageDialog(null, "Base do ret�ngulo = " + String.format("%.2f",objetoRetangulo.getBase())
				+ "\nAltura do ret�ngulo = "+ String.format("%.2f",objetoRetangulo.getAltura())
				+ "\nNumero de lados = " + Retangulo.getNumLados()
				+ "\n�rea do ret�ngulo = " + String.format("%.2f",objetoRetangulo.calculcarArea())
				+ "\nPerimetro do ret�ngulo = " + String.format("%.2f",objetoRetangulo.calcularPerimetro())
				+ "\nDiagonal do ret�ngulo = " + String.format("%.2f", objetoRetangulo.calcularDiagonal()));
	}
}
