package lista05q05;

import javax.swing.JOptionPane;

public class NumeroInteiro
{	
	private int numero;
	
	public void setNumero(int n)
	{
		numero=n;
	}
	
	public int getNumero()
	{
		return numero;
	}
	
	public NumeroInteiro()
	{
		numero = (Integer.parseInt(JOptionPane.showInputDialog("Digite um n�mero inteiro")));
	}
	
	public int CalcularSoma (int num)
	{
		return numero+num;
	}
	
	public int CalcularSubtracao (int num)
	{
		return numero-num;
	}
	
	public float CalcularDivisao (int Divisor)
	{		
		return (float)numero/Divisor;
	}
	
	public int CalcularProduto (int num)
	{
		return numero*num;
	}
	
	public int CalcularModuloDivisao (int Divisor)
	{
		return numero%Divisor;
	}
	
	public double CalcularRaiz()
	{
		return Math.sqrt(numero);
	}
	
	public double CalularPotencia (int Expoente)
	{
		return Math.pow(numero, Expoente);
	}

}
