package lista05q05;

import javax.swing.JOptionPane;

public class TesteNumeroInteiro {

	public static void main(String[] args) {
		NumeroInteiro ObjNumInt = new NumeroInteiro();		
		
		int num = Integer.parseInt(JOptionPane.showInputDialog("Digite um segundo n�mero inteiro"));
		
		JOptionPane.showMessageDialog(null, "Soma (" + ObjNumInt.getNumero() + "+" +num +")= "+ ObjNumInt.CalcularSoma(num)+
				"\nSubtra��o (" + ObjNumInt.getNumero() + "-" +num +")= "+ ObjNumInt.CalcularSubtracao(num)+
				"\nDivis�o (" + ObjNumInt.getNumero() + "/" +num +")= "+ String.format("%.2f", ObjNumInt.CalcularDivisao(num)) +
				"\nProduto (" + ObjNumInt.getNumero() + "*" +num +")= "+ ObjNumInt.CalcularProduto(num)+
				"\nM�dulo da divis�o (" + ObjNumInt.getNumero() + "/" +num +")= "+ ObjNumInt.CalcularModuloDivisao(num)+
				"\nRaiz Quadrada de "+ObjNumInt.getNumero() +"= "+ String.format("%.2f", ObjNumInt.CalcularRaiz()) +
				"\n"+ObjNumInt.getNumero() + " elevado a " +num + " = " + String.format("%.0f", ObjNumInt.CalularPotencia(num)) );
	}

}
