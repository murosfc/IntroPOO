package lista05q06;

import javax.swing.JOptionPane;

public class TestePlanoCartesiano {

	public static void main(String[] args) {
		PlanoCartesiano ObjPonto1 = new PlanoCartesiano();
		PlanoCartesiano ObjPonto2 = new PlanoCartesiano();	
		
		JOptionPane.showMessageDialog(null, "Ponto 1 ("+ObjPonto1.getX() +","+ObjPonto1.getY()+")"
				+"\nPonto 2 ("+ObjPonto2.getX() +","+ObjPonto2.getY()+")"
				+"\nDist�ncia entre os pontos = " + String.format("%.2f", ObjPonto1.CalcularDistanciaPontos(ObjPonto2))				
				+"\nProduto cartesiano dos pontos = " + ObjPonto1.CalcularProdutoCartesiano(ObjPonto2));
		
	}

}
