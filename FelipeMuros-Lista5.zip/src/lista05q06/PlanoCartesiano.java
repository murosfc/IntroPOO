package lista05q06;

import javax.swing.JOptionPane;

public class PlanoCartesiano {
	private int CoordenadaX,CoordenadaY;	
	
	public void setX (int x)
	{
		CoordenadaX=x;
	}
	
	public void setY (int y)
	{
		CoordenadaY=y;
	}
	
	public int getX()
	{
		return CoordenadaX;
	}
	
	public int getY()
	{
		return CoordenadaY;
	}
	
	public PlanoCartesiano()
	{		
		CoordenadaX = Integer.parseInt(JOptionPane.showInputDialog("Digite a coordenada X do ponto"));
		CoordenadaY = Integer.parseInt(JOptionPane.showInputDialog("Digite a coordenada Y do ponto"));
	}
	
	public double CalcularDistanciaPontos (PlanoCartesiano Objeto)
	{
		return Math.sqrt(Math.pow((CoordenadaX-Objeto.CoordenadaX),2)+Math.pow((CoordenadaY-Objeto.CoordenadaY),2));
	}
	
	public String CalcularProdutoCartesiano (PlanoCartesiano Objeto)
	{
		return ("{("+ Objeto.CoordenadaX +","+CoordenadaX+");("+ Objeto.CoordenadaX +","+CoordenadaY+");("+ Objeto.CoordenadaY +","+CoordenadaX+");("+ Objeto.CoordenadaY +","+CoordenadaY+")}");
		
	}

}
