module FelipeMuros {
	requires java.desktop;
}