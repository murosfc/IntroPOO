package prova;

public class Prova {

	public static void main(String[] args) {
		Hotel objHotel = new Hotel();
		Hospede objHospede = new Hospede();
		objHotel.imprimirDados();
		objHospede.imprimirDados();
	}

}
